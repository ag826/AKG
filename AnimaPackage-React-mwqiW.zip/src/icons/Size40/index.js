export { Size40 } from "./Size40";
