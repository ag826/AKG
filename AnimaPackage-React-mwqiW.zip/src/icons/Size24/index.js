export { Size24 } from "./Size24";
