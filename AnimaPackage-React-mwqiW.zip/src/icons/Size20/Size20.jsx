/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size20 = ({ className }) => {
  return (
    <svg
      className={`size-20 ${className}`}
      fill="none"
      height="20"
      viewBox="0 0 20 20"
      width="20"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M9.99984 5.83333C9.99984 4.94928 9.64865 4.10143 9.02353 3.47631C8.39841 2.85119 7.55056 2.5 6.6665 2.5H1.6665V15H7.49984C8.16288 15 8.79876 15.2634 9.2676 15.7322C9.73645 16.2011 9.99984 16.837 9.99984 17.5M9.99984 5.83333V17.5M9.99984 5.83333C9.99984 4.94928 10.351 4.10143 10.9761 3.47631C11.6013 2.85119 12.4491 2.5 13.3332 2.5H18.3332V15H12.4998C11.8368 15 11.2009 15.2634 10.7321 15.7322C10.2632 16.2011 9.99984 16.837 9.99984 17.5"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
      />
    </svg>
  );
};
