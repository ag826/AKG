/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size403 = ({ className }) => {
  return (
    <svg
      className={`size-40-3 ${className}`}
      fill="none"
      height="40"
      viewBox="0 0 40 40"
      width="40"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M26.6667 35V8.33333C26.6667 7.44928 26.3155 6.60143 25.6904 5.97631C25.0653 5.35119 24.2174 5 23.3334 5H16.6667C15.7827 5 14.9348 5.35119 14.3097 5.97631C13.6846 6.60143 13.3334 7.44928 13.3334 8.33333V35M6.66671 11.6667H33.3334C35.1743 11.6667 36.6667 13.1591 36.6667 15V31.6667C36.6667 33.5076 35.1743 35 33.3334 35H6.66671C4.82576 35 3.33337 33.5076 3.33337 31.6667V15C3.33337 13.1591 4.82576 11.6667 6.66671 11.6667Z"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="3.5"
      />
    </svg>
  );
};
