/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { BookOpen } from "../../icons/BookOpen";
import { Briefcase } from "../../icons/Briefcase";
import { Size481 } from "../../icons/Size481";
import { Size482 } from "../../icons/Size482";
import "./style.css";

export const Rectangle = ({ className }) => {
  return (
    <div className={`rectangle ${className}`}>
      <div className="overlap-group">
        <div className="overlap">
          <img
            className="whatsapp-image"
            alt="Whatsapp image"
            src="/img/whatsapp-image-2022-03-25-at-10-32-25-pm-1.png"
          />
          <div className="div" />
        </div>
        <div className="group">
          <Briefcase className="size-48-3" color="#B3B3B3" />
          <Size482 className="crosshair" color="#B3B3B3" />
          <Size481 className="map-pin" color="#B3B3B3" />
          <BookOpen className="book-open" color="#B3B3B3" />
        </div>
      </div>
    </div>
  );
};
