/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size162 = ({ className }) => {
  return (
    <svg
      className={`size-16-2 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_435_117)">
        <path
          className="path"
          d="M14.6667 7.99992C14.6667 11.6818 11.6819 14.6666 8.00004 14.6666M14.6667 7.99992C14.6667 4.31802 11.6819 1.33325 8.00004 1.33325M14.6667 7.99992H12M8.00004 14.6666C4.31814 14.6666 1.33337 11.6818 1.33337 7.99992M8.00004 14.6666V11.9999M1.33337 7.99992C1.33337 4.31802 4.31814 1.33325 8.00004 1.33325M1.33337 7.99992H4.00004M8.00004 1.33325V3.99992"
          stroke="#1E1E1E"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="1.6"
        />
      </g>
      <defs className="defs">
        <clipPath className="clip-path" id="clip0_435_117">
          <rect className="rect" fill="white" height="16" width="16" />
        </clipPath>
      </defs>
    </svg>
  );
};
