/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size323 = ({ className }) => {
  return (
    <svg
      className={`size-32-3 ${className}`}
      fill="none"
      height="32"
      viewBox="0 0 32 32"
      width="32"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M21.3333 28V6.66667C21.3333 5.95942 21.0523 5.28115 20.5522 4.78105C20.0521 4.28095 19.3739 4 18.6666 4H13.3333C12.626 4 11.9478 4.28095 11.4477 4.78105C10.9476 5.28115 10.6666 5.95942 10.6666 6.66667V28M5.33329 9.33333H26.6666C28.1394 9.33333 29.3333 10.5272 29.3333 12V25.3333C29.3333 26.8061 28.1394 28 26.6666 28H5.33329C3.86053 28 2.66663 26.8061 2.66663 25.3333V12C2.66663 10.5272 3.86053 9.33333 5.33329 9.33333Z"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="3"
      />
    </svg>
  );
};
