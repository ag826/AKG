/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size202 = ({ className }) => {
  return (
    <svg
      className={`size-20-2 ${className}`}
      fill="none"
      height="20"
      viewBox="0 0 20 20"
      width="20"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_435_118)">
        <path
          className="path"
          d="M18.3333 10.0001C18.3333 14.6025 14.6023 18.3334 9.99996 18.3334M18.3333 10.0001C18.3333 5.39771 14.6023 1.66675 9.99996 1.66675M18.3333 10.0001H15M9.99996 18.3334C5.39759 18.3334 1.66663 14.6025 1.66663 10.0001M9.99996 18.3334V15.0001M1.66663 10.0001C1.66663 5.39771 5.39759 1.66675 9.99996 1.66675M1.66663 10.0001H4.99996M9.99996 1.66675V5.00008"
          stroke="#1E1E1E"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
        />
      </g>
      <defs className="defs">
        <clipPath className="clip-path" id="clip0_435_118">
          <rect className="rect" fill="white" height="20" width="20" />
        </clipPath>
      </defs>
    </svg>
  );
};
