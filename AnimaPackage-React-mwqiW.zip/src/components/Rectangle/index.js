export { Rectangle } from "./Rectangle";
