/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import "./style.css";

export const Frame = ({ className }) => {
  return (
    <div className={`frame ${className}`}>
      <div className="div-2">
        <div className="text-wrapper">About</div>
        <div className="text-wrapper">Projects &amp; Research</div>
        <div className="text-wrapper">Connect</div>
      </div>
      <div className="line-wrapper">
        <img className="line" alt="Line" src="/img/line-1.svg" />
      </div>
      <img className="img" alt="Frame" src="/img/frame-3.svg" />
    </div>
  );
};
