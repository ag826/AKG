/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size40 = ({ className }) => {
  return (
    <svg
      className={`size-40 ${className}`}
      fill="none"
      height="40"
      viewBox="0 0 40 40"
      width="40"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M20.0002 11.6667C20.0002 9.89856 19.2978 8.20286 18.0475 6.95262C16.7973 5.70238 15.1016 5 13.3335 5H3.3335V30H15.0002C16.3262 30 17.598 30.5268 18.5357 31.4645C19.4734 32.4021 20.0002 33.6739 20.0002 35M20.0002 11.6667V35M20.0002 11.6667C20.0002 9.89856 20.7025 8.20286 21.9528 6.95262C23.203 5.70238 24.8987 5 26.6668 5H36.6668V30H25.0002C23.6741 30 22.4023 30.5268 21.4646 31.4645C20.5269 32.4021 20.0002 33.6739 20.0002 35"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="3.5"
      />
    </svg>
  );
};
