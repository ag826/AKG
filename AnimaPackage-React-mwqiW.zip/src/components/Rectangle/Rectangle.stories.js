import { Rectangle } from ".";

export default {
  title: "Components/Rectangle",
  component: Rectangle,
};

export const Default = {
  args: {
    className: {},
  },
};
