/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size322 = ({ className }) => {
  return (
    <svg
      className={`size-32-2 ${className}`}
      fill="none"
      height="32"
      viewBox="0 0 32 32"
      width="32"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M29.3333 16.0001C29.3333 23.3639 23.3638 29.3334 16 29.3334M29.3333 16.0001C29.3333 8.63628 23.3638 2.66675 16 2.66675M29.3333 16.0001H24M16 29.3334C8.63616 29.3334 2.66663 23.3639 2.66663 16.0001M16 29.3334V24.0001M2.66663 16.0001C2.66663 8.63628 8.63616 2.66675 16 2.66675M2.66663 16.0001H7.99996M16 2.66675V8.00008"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="3"
      />
    </svg>
  );
};
