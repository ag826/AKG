export { Size32 } from "./Size32";
