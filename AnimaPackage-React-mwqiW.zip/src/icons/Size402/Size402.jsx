/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size402 = ({ className }) => {
  return (
    <svg
      className={`size-40-2 ${className}`}
      fill="none"
      height="40"
      viewBox="0 0 40 40"
      width="40"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M36.6667 19.9999C36.6667 29.2047 29.2048 36.6666 20 36.6666M36.6667 19.9999C36.6667 10.7952 29.2048 3.33325 20 3.33325M36.6667 19.9999H30M20 36.6666C10.7953 36.6666 3.33337 29.2047 3.33337 19.9999M20 36.6666V29.9999M3.33337 19.9999C3.33337 10.7952 10.7953 3.33325 20 3.33325M3.33337 19.9999H10M20 3.33325V9.99992"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="3.5"
      />
    </svg>
  );
};
